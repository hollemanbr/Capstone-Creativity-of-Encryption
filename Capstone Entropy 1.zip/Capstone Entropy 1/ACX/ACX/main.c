/*
 * ACX.c
 *
 * Created: 3/24/2018 11:56:44
 * Author : hollemanbr and shieldsjp
 */ 
#include <avr/io.h>
#include "acx.h"
#include "acxserial.h"

//ms durations
#define FLASHON 250
#define FLASHOFF 125
//No leds 0x00 - all leds 0x0F
volatile int ledsFlash = 0x0F;

//ms durations
#define ROTATEON 200
#define ROTATEOFF 1
//led rotate leds 0 to 3.
volatile int rotStartVal = 0;
//Value used to increment rotShiftVal before modding
volatile int rotIncrVal = 1;
//value used to mod rotShiftVal after incrementing 
volatile int rotModVal = 4;

void threadA();
void threadA1();
void threadA2();
void rotatingthread();
void flashingthread();
void printUp();
void printLow();
void off();
volatile int state = 0;
volatile int printVal = 1;

char outputLowVal(int number);
char outputUpVal(int number);

//Flash lower
volatile int lowerCase;
//Rotate upper
volatile int upperCase;
volatile char low;
volatile char upper;
volatile int wCase;

int main(void)
{
	DDRF = 0x0F;
	PORTF = 0xC0;
	//After calling x_init(), the running thread is "thread 0"
	x_init();
	x_new(1,threadA,true);
	Serial_open(0, 115200L, SERIAL_8N1);
	lowerCase = 0;
	upperCase = 0;
	wCase = 0;
	DDRB = 0x80;
	while (1) {
		PORTB ^= 0x80;
		x_delay(100); //100 ms
	}
}

void printLow(){
	while(1){
		Serial0_poll_write(low);
		x_disable(3);
		x_yield();	
	}
}
void printUp(){
	while(1){
		Serial0_poll_write(upper);
		x_disable(3);
		x_yield();	
	}
}

void threadA(){
	while(1){
		x_delay(1);
		if(lowerCase >= 0 && wCase == 0 && state == 0 && printVal == 0)
		{
			low = outputLowVal((lowerCase % 26));
			//lowerCase = 0;
			x_new(3, printLow, true);
			printVal = 1;
		}
		if(upperCase >= 0 && wCase != 0 && state == 0 && printVal == 0)
		{
			upper = outputUpVal((upperCase % 26) );
			//upperCase = 0;
			x_new(3, printUp, true);
			printVal = 1;
		}
		if((PINF | ~(1 << 6)) == ~(1 << 6)) {
			x_new(1, threadA1, true);
		}
		if((PINF | ~(1 << 7)) == ~(1 << 7)) {
			x_new(1, threadA2, true);
		}
		x_yield();	
	}
}

void threadA1(){
	while(1){
		x_delay(1);
		if(((PINF & (1 << 6)) == (1 << 6)) && state == 0) {
			state = 1;
			PORTF &= 0xF0;
			x_new(2, rotatingthread, true);
			x_new(1, threadA, true);
		}
		else if(((PINF & (1 << 6)) == (1 << 6)) && state == 1) {
			state = 0;
			PORTF &= 0xF0;
			x_new(2,off,true);
			x_new(1, threadA, true);
		}
		else if(((PINF & (1 << 6)) == (1 << 6)) && state == 2) {
			state = 1;
			PORTF &= 0xF0;
			x_new(2, rotatingthread, true);
			x_new(1, threadA, true);
		}
		x_yield();	
	}
}

void threadA2(){
	while(1){
		x_delay(1);
		if(((PINF & (1 << 7)) == (1 << 7)) && state == 0) {
			state = 2;
			PORTF &= 0xF0;
			x_new(2, flashingthread, true);
			x_new(1, threadA, true);
		}
		else if(((PINF & (1 << 7)) == (1 << 7)) && state == 1) {
			state = 2;
			PORTF &= 0xF0;
			x_new(2, flashingthread, true);
			x_new(1, threadA, true);
		}
		else if(((PINF & (1 << 7)) == (1 << 7)) && state == 2) {
			state = 0;
			PORTF &= 0xF0;
			x_new(2,off,true);
			x_new(1, threadA, true);
		}
		x_yield();
	}
}

void rotatingthread() {
	int rotShiftVal = 0;
	while(1){
		if(rotShiftVal == 0){
			rotShiftVal = rotStartVal;
		}
		PORTF ^= (1 << rotShiftVal);
		x_delay(ROTATEON);
		PORTF ^= (1 << rotShiftVal);
		x_delay(ROTATEOFF);
		rotShiftVal = ((rotShiftVal + rotIncrVal) % rotModVal);
		wCase = 1;
		upperCase += 1;
		x_yield();
	}
}

void flashingthread() {
	while(1){
		PORTF ^= ledsFlash;
		x_delay(FLASHON);
		PORTF ^= ledsFlash;
		x_delay(FLASHOFF);
		wCase = 0;
		lowerCase += 1;
		x_yield();
	}
}

void off() {
	printVal = 0;
	while(1){
		PORTF &= 0xF0;
		x_yield();	
	}
}

char outputLowVal(int number) {
	switch(number)
	{
		case 1:
			return 'a';
			break;
		case 2:
			return 'b';
			break;
		case 3:
			return 'c';
			break;
		case 4:
			return 'd';
			break;
		case 5:
			return 'e';
			break;
		case 6:
			return 'f';
			break;
		case 7:
			return 'g';
			break;
		case 8:
			return 'h';
			break;
		case 9:
			return 'i';
			break;
		case 10:
			return 'j';
			break;
		case 11:
			return 'k';
			break;
		case 12:
			return 'l';
			break;
		case 13:
			return 'm';
			break;
		case 14:
			return 'n';
			break;
		case 15:
			return 'o';
			break;
		case 16:
			return 'p';
			break;
		case 17:
			return 'q';
			break;
		case 18:
			return 'r';
			break;
		case 19:
			return 's';
			break;
		case 20:
			return 't';
			break;
		case 21:
			return 'u';
			break;
		case 22:
			return 'v';
			break;
		case 23:
			return 'w';
			break;
		case 24:
			return 'x';
			break;
		case 25:
			return 'y';
			break;
		case 26:
			return 'z';
			break;
		default:
			return 'a';
			break;
	}
}

char outputUpVal(int number) {
	switch(number)
	{
		case 1:
			return 'A';
			break;
		case 2:
			return 'B';
			break;
		case 3:
			return 'C';
			break;
		case 4:
			return 'D';
			break;
		case 5:
			return 'E';
			break;
		case 6:
			return 'F';
			break;
		case 7:
			return 'G';
			break;
		case 8:
			return 'H';
			break;
		case 9:
			return 'I';
			break;
		case 10:
			return 'J';
			break;
		case 11:
			return 'K';
			break;
		case 12:
			return 'L';
			break;
		case 13:
			return 'N';
			break;
		case 14:
			return 'N';
			break;
		case 15:
			return 'O';
			break;
		case 16:
			return 'P';
			break;
		case 17:
			return 'Q';
			break;
		case 18:
			return 'R';
			break;
		case 19:
			return 'S';
			break;
		case 20:
			return 'T';
			break;
		case 21:
			return 'U';
			break;
		case 22:
			return 'V';
			break;
		case 23:
			return 'W';
			break;
		case 24:
			return 'X';
			break;
		case 25:
			return 'Y';
			break;
		case 26:
			return 'Z';
			break;
		default:
			return 'A';
			break;
	}
}